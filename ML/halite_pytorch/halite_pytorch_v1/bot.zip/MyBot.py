from pytorch_bot.bot import Bot

Bot(location="model/pytorch_bot_v1.pt",name="PytorchBot").play()
